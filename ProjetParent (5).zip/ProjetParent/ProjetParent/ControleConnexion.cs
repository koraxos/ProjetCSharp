﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetParent
{
    class ControleConnexion
    {
        public Parent parentValide(String nom, String motdepasse)
        {
            Parent p=null;
            // On teste dans la base de données si le parent existe

            // et il faut tester si les identifiants sont bons

            // Si oui, on renvoit le parent

            return p;
        }

        public Boolean insertionParent(Parent p)
        {
            Boolean insertionOK=true;
            // On insère le parent p dans la BD


            return insertionOK;
        }

        public Eleve[] affichageEnfant(Parent p)
        {
            Eleve[] tabE= new Eleve[5];
            // on veut retourner la liste des enfants qui ont été ajoutés par le parent
            return tabE;
        }

        public Boolean insertionEnfant(Eleve e)
        {
            // on veut ajouter un nouvel enfant

            return true;
        }
        public Eleve cetEleve(String nom, String prenom)
        {
            // il faut que l'on renvoit un eleve à partir du nom prénom
            Eleve e = null;

            return e;
        }

        public int nombreNiveau(Eleve e)
        {
            int niveau = 3;
            // il faut récupérer le niveau de l'enfant

            return niveau;
        }
        
        

    }
}
